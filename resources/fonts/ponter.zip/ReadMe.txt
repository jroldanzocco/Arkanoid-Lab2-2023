If You want use this font for commercial purposes please write me to: morderdrakonovich@gmail.com.

Copyright � 2020 by Vasily Draigo aka Daymarius. All rights reserved.
